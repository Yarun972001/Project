import portfolio from "../Img/portfolio.png"
import webpage from "../Img/webpage.png"
import adminpanel from "../Img/adminpanel.png"


const ProjectCardData =[
    {
        imgsrc:portfolio,
        title :"Portfolio ",
        text: "This Project is implemented using HTML for Structure, CSS for styling, JavaScript for interactivity and React.js for making a single page website.",
        view:""

    },
    {
        imgsrc:webpage,
        title :"Home Page ",
        text:" Shopping site home page with Styled- component",
        view:""
        
    },
    {
        imgsrc:adminpanel,
        title :"Admin Panel",
        text: "In this project we create our personal API, fetch it and see it in our admin panel.",
        view:""
        
    }
]

export default ProjectCardData;