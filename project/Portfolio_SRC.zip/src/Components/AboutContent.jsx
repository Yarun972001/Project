import React from 'react'
import { Link } from 'react-router-dom'
import html from "../Img/html.webp"
import react from "../Img/react.png"
// import  main from"../Img/main.gif"
// import  main2 from"../Img/main2.gif"
import "./Aboutcontent.css"

function AboutContent() {
  return (
    <div className="work-container">
    <h1 className="project-heading">A <span className="Arunn">B </span> O<span className="Arunn"> U  </span>T </h1>
<hr />
    <div className="about">  
        <div className="left">
        <h1>Who Am I?</h1>
        <p>
            I'm a React Front-end Developer.
            I Create responsive secure website for my clients.
        </p>
        <Link to="/Contact">
            <button className='btn'>Contatct</button>
        </Link>
        </div>

        <div className="right">
        <div className="img-container">
            <div className="img-stack top">
                <img src={html} alt="true" className='img' />
            </div>

            <div className="img-stack bottom">
                <img src={react} alt="true" className='img' />
            </div>
        </div>
        </div>
    </div>
    </div>
  )
}

export default AboutContent