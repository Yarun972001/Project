import React from 'react'
import "./Formstyle.css"

function Form() {
  return (
   <div className="form">
                <h1 className="project-heading"> C <span className="Arunn"> O </span>    N<span className="Arunn"> T </span> A <span className="Arunn"> C </span> T </h1>
                <hr/>
    <form>
        <label>YOUR NAME</label>
        <input type='text' placeholder='Enter your name'></input>
        <label>EMAIL</label>
        <input type='email' placeholder='Enter email'></input>
        <label>CONTACT NUMBER</label>
        <input type='number' placeholder='Enter your number'></input>
        <label>MESSAGE</label>
        <textarea rows="6" placeholder='Type your message here' />
        <button className='btn'>SBMIT</button>
    </form>
   </div>
  )
}

export default Form