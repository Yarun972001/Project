import React from 'react'
import "./Heroimgstyle.css"
import black from "../Img/black.jpg"
import { Link } from 'react-router-dom'

function Heroimg() {
  return (
    <div className="hero">
        <div className="mask">
          <img className='into-img' src={black} alt="office" />  
        </div>
        <div className="content">
          <p>Hii👋, My name is<span className="Arunn"> <b> Arun Yadav </b></span></p>
          <h1>Front-end Developer</h1>
          <div>
            <Link to="/Project" className='btn'>Project</Link>
            <Link to="/Contact" className='btn btn-light'>Contact</Link>
          </div>
        </div>
    </div>
  )
}

export default Heroimg