import React from 'react'
import Navbar from '../Components/Navbar'
import Heroimg from '../Components/Heroimg'
import Footer from '../Components/Footer'
import Work from '../Components/Work'
import WorkCard from '../Components/WorkCard'
import AboutContent from '../Components/AboutContent'
import Form from '../Components/Form'

function Home() {
  return (
    <div>
      <Navbar/>
      <Heroimg/>
      <Work/>
      <AboutContent/>
      <Form/>
      <Footer/>
    </div>
  )
}

export default Home