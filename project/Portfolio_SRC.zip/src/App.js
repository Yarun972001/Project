import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Home from './Pages/Home'
import Project from './Pages/Project'
import About from './Pages/About'
import Contact from './Pages/Contact'


function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<><Home/></>}/>
      <Route path='/Project' element={<><Project/></>}/>
      <Route path='/About' element={<><About/></>}/>
      <Route path='/Contact' element={<><Contact/></>}/>
    </Routes>
    </BrowserRouter>
  )
}

export default App