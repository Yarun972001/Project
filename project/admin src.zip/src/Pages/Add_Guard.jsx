import React,{useState} from 'react'
import axios from 'axios'

import { toast } from 'react-toastify';

function Add_Guard() {


    const [formvalue,setFormvalue]=useState({
        id:"",
        cate_name:"",
        cate_img:"",
        cate_email:"",
    });

    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const submitHandel= async (e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/guard`,formvalue);
        if(res.status==201)
        {
            toast.success('guard Add Success');
            setFormvalue({...formvalue,cate_name:"",cate_img:"",cate_email:""});
            return false;
        }
        
    }

    return (
        <div className="wrapper">
        <div className="row ">
          <div className="col-md-8 offset-md-3">
          <h1 className="text-center" ><i><u>Add Guard</u></i></h1>
                    
                        <div className="panel panel-primary">
                            <div className="panel-body">
                                <form method="post">
                                    <div className="form-group">
                                        <label>Enter Guard Name</label>
                                        <input name="cate_name" onChange={changeHandel} value={formvalue.cate_name} className="form-control" type="text" />           
                                    </div>
                                    <div className="form-group">
                                        <label>Upload Guard Image Path</label>
                                        <input name="cate_img" onChange={changeHandel} value={formvalue.cate_img} className="form-control" type="url" />
                                    </div>
                                    <div className="form-group">
                                        <label>Add Guard email</label>
                                        <input name="cate_email" onChange={changeHandel} value={formvalue.cate_email} className="form-control" type="email" />
                                    </div>
                                    <button type="submit" onClick={submitHandel} className="btn btn-info">Submit </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
    </div>
    

    )
}

export default Add_Guard