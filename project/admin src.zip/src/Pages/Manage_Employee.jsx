import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';


function Manage_Employee() {

    const [data, setData] = useState([]);

    useEffect(() => {
        fetch();
    }, []);

    const fetch = async () => {
        const res = await axios.get(`http://localhost:3000/employee`);
        //console.log(res.data);
        setData(res.data);
    }

    const deletehandel=async(id)=>{
        const res=await axios.delete(`http://localhost:3000/employee/${id}`);
        //console.log(res);
        if(res.status==200)
        {
            toast.success('Employee Delete Success');
            fetch();
        }
    }

  return (
    <div className="wrapper">
    <div className="row ">
      <div className="col-md-10 offset-md-2">
      <h1 className="text-center" ><i><u>Manage Employee</u></i></h1>
    <table className="table table-bordered">
        <thead>
            <tr>
                <th >ID</th>
                <th >Image</th>
                <th >Name</th>
                <th >Position</th>
                <th >Email</th>
                <th >Number</th>
                <th >Action</th>
            </tr>
        </thead>
        <tbody>
            {
                data.map((value) => {

                    return (
                        <tr>
                            <td>{value.id}</td>
                            <td><img src={value.employee_img} alt="" width="100px" height="100px" /></td>
                            <td>{value.employee_name}</td>
                            <td>{value.employee_position}</td>
                            <td>{value.employee_email}</td>
                            <td>{value.employee_number}</td>
                            <td>
                                <button className='btn btn-danger' onClick={()=>deletehandel(value.id)}>Delete</button>
                            </td>
                        </tr>
                    )
                })
            }

        </tbody>
    </table>
</div>
</div>
</div>
  )
}

export default Manage_Employee