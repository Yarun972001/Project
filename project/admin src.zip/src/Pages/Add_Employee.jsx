import React,{useState} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';

function Add_Employee() {

    const [formvalue,setFormvalue]=useState({
        id:"",
        employee_name:"",
        employee_position:"",
        employee_email:"",
        employee_number:"",
        employee_img:""
    });
    
    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }
    
    const submitHandel= async (e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/employee`,formvalue);
        if(res.status==201)
        {
            toast.success('Categories Add Success');
            setFormvalue({...formvalue,employee_name:"",
            employee_position:"",
            employee_email:"",
            employee_number:"",
            employee_img:""});
            return false;
        }
        
    }

  return (
<div className="wrapper">
    <div className="row ">
      <div className="col-md-8 offset-md-3">
        <h1 className="text-center" ><i><u>Add Employee</u></i></h1>
  <form>
    {/* Employee Name */}
    <div className="form-group">
      <label htmlFor="employeeName">Employee Name:</label>
      <input name="employee_name" className="form-control" type='text' onChange={changeHandel} value={formvalue.employee_name} id="employeeName" placeholder="Enter employee name" />
    </div>
    {/* Employee Position */}
    <div className="form-group">
      <label htmlFor="employeePosition">Position:</label>
      <input name="employee_position" className="form-control" type='text' onChange={changeHandel} value={formvalue.employee_position} id="employeePosition" placeholder="Enter employee position" />
    </div>
    {/* Employee Email */}
    <div className="form-group">
      <label htmlFor="employeeEmail">Email address:</label>
      <input name="employee_email" className="form-control" type='email' onChange={changeHandel} value={formvalue.employee_email} id="employeeEmail" placeholder="Enter email" />
    </div>
    {/* Employee Phone Number */}
    <div className="form-group">
      <label htmlFor="employeePhone">Phone Number:</label>
      <input name="employee_number" className="form-control" type='number' onChange={changeHandel} value={formvalue.employee_number} id="employeePhone" placeholder="Enter phone number" />
    </div>

    <div className="form-group">
      <label htmlFor="productImage">Employee Image:</label>
      <input name="employee_img" type="url" className="form-control" onChange={changeHandel} value={formvalue.employee_img} id="productImage" placeholder="Enter product url"  />
    </div>
    {/* Submit Button */}
    <button type="submit" className="btn btn-primary" onClick={submitHandel}>Submit</button>
  </form>
</div>
</div>
</div>

  )
}

export default Add_Employee