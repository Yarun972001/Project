import React from 'react'
import { NavLink } from 'react-router-dom'

function Dashboard() {
    return (

        <div className='wrapper'>
            <div className="container">
                <h1 className="text-center" ><i><u>Dashboard</u></i></h1>
                <div className="row">

                    <div className="col-md-3 p-5">
                        <div className="col-md-4 offset-md-4">
                            <div className="card" style={{ width: '18rem' }}>
                                <img className="card-img-top" src="https://tse3.mm.bing.net/th?id=OIP.A5rZGnnmCAixyCKce89DzwHaHa&pid=Api&P=0&h=180" height="150px" alt="Card image cap" />
                                <div className="card-body">
                                    <h5 className="card-title">User</h5>
                                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <NavLink to="/Add_User" className="btn btn-secondary">Add Users</NavLink>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="col-md-3 p-5">
                        <div className="col-md-4 offset-md-7">
                            <div className="card" style={{ width: '18rem' }}>
                                <img className="card-img-top" src="https://tse3.explicit.bing.net/th?id=OIP.klUOb62xL61X7r9ROyls8AHaHa&pid=Api&P=0&h=180" height="150px" alt="Card image cap" />
                                <div className="card-body">
                                    <h5 className="card-title">Employee</h5>
                                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <NavLink to="/Add_employee" className="btn btn-secondary">Add Employee</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-3 p-5">
                        <div className="col-md-4 offset-md-10">
                            <div className="card" style={{ width: '18rem' }}>
                                <img className="card-img-top" src="https://tse4.mm.bing.net/th?id=OIP.IgH8WoDZBH9p_cKF7R5oiAHaE8&pid=Api&P=0&h=180" height="150px" alt="Card image cap" />
                                <div className="card-body">
                                    <h5 className="card-title">Guard</h5>
                                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <NavLink to="/Add_Guard" className="btn btn-secondary">Add Guard</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-3 p-5">
                        <div className="col-md-4 offset-md-10">
                            <div className="card" style={{ width: '18rem' }}>
                                <img className="card-img-top" src="https://tse1.mm.bing.net/th?id=OIP.fnaN2CpD_Dn4n3hgeurVkwHaH0&pid=Api&P=0&h=180" height="150px" alt="Card image cap" />
                                <div className="card-body">
                                    <h5 className="card-title">Contact</h5>
                                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <NavLink to="/Add_Contact" className="btn btn-secondary">Contact Us</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-5 p-5">
                        <div className="col-md-4 offset-md-10">
                            <div className="card" style={{ width: '18rem' }}>
                                <img className="card-img-top" src="https://tse4.mm.bing.net/th?id=OIP.rP7Ze_rxgMB0rTLnuBazuwHaHa&pid=Api&P=0&h=180" height="150px" alt="Card image cap" />
                                <div className="card-body">
                                    <h5 className="card-title">Website</h5>
                                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <NavLink to="http://localhost:3002/" className="btn btn-secondary">Go Website</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>



    )
}

export default Dashboard