import React,{useState} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
function Add_User() {
    const [formvalue,setFormvalue]=useState({
        id:"",
        user_name:"",
        user_img:"",
        user_email:"",
        user_password:"",
        user_number:""
    });
    const changeHandel=(e)=>{
      setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
      console.log(formvalue);
  }
  
  const submitHandel= async (e)=>{
      e.preventDefault();
      const res=await axios.post(`http://localhost:3000/user`,formvalue);
      if(res.status==201)
      {
          toast.success('User Added Succesfully');
          setFormvalue({...formvalue,user_name:"",user_img:"",user_email:"",user_password:"",user_number:""});
          return false;
      }
      
  }

  return (
    <div className="wrapper">
    <div className="row ">
      <div className="col-md-8 offset-md-3">
        <h1 className="text-center" ><i><u>Add User</u></i></h1>
        <form >
        <div className="form-group">
            <label htmlFor="userImage">User Image</label>
            <input name="user_img" type="url" className="form-control"   onChange={changeHandel} value={formvalue.user_img} id="userImage"  placeholder="Enter img url" />
          </div>
          <div className="form-group">
            <label htmlFor="userName">User Name</label>
            <input name="user_name" type="text" className="form-control text-dark"   onChange={changeHandel} value={formvalue.user_name} id="userName" placeholder="Enter User Name" />
          </div>
          <div className="form-group">
            <label htmlFor="userName">User Number</label>
            <input name="user_number" type="text" className="form-control text-dark"   onChange={changeHandel} value={formvalue.user_number} id="userName" placeholder="Enter User Name" />
          </div>
          <div className="form-group">
            <label htmlFor="userEmail">Email</label>
            <input name="user_email" type="text" className="form-control"  onChange={changeHandel} value={formvalue.user_email} id="userEmail" placeholder="Enter email" />
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input name="user_password" type="password" className="form-control" onChange={changeHandel} value={formvalue.user_password} id="password" placeholder="Enter your password" required/>
        </div>
          <button type="submit" className="btn btn-primary"  onClick={submitHandel} >Submit</button>
        </form>
      </div>
    </div>
    </div>
  )
}

export default Add_User