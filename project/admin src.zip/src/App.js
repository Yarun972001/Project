import React from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import './Style/App.css'
import Add_User from './Pages/Add_User'
import Manage_User from './Pages/Manage_User'
import Sidebar from './Components/Sidebar'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'


import Add_Guard from './Pages/Add_Guard'
import Manage_Guard from './Pages/Manage_Guard'
import Add_product from './Pages/Add_product'
import Manage_product from './Pages/Manage_product'
import Manage_Contact from './Pages/Manage_Contact'
import Add_Contact from './Pages/Add_Contact'
import Dashboard from './Pages/Dashboard'
import Add_Employee from './Pages/Add_Employee'
import Manage_Employee from './Pages/Manage_Employee'

function App() {
  return (
 <BrowserRouter>
< ToastContainer />

 <Routes>
 <Route path="/" element={<><Sidebar/><Dashboard/></>}></Route>
      <Route path="/Add_User" element={<><Sidebar/><Add_User/></>}></Route>
    
      <Route path="/Manage_User" element={<><Sidebar/><Manage_User/></>}></Route>
      <Route path="/Manage_Employee" element={<><Sidebar/><Manage_Employee/></>}></Route>
      <Route path="/Add_Employee" element={<><Sidebar/><Add_Employee/></>}></Route>
       
      <Route path="/Add_Guard" element={<><Sidebar/><Add_Guard/></>}></Route>
      <Route path="/Manage_Guard" element={<><Sidebar/><Manage_Guard/></>}> </Route>
      <Route path="/Add_product" element={<><Sidebar/><Add_product/></>}></Route>
      <Route path="/Manage_product" element={<><Sidebar/><Manage_product/></>}></Route>
      <Route path="/Manage_Contact" element={<><Sidebar/><Manage_Contact/></>}></Route>
      <Route path="/Add_Contact" element={<><Sidebar/><Add_Contact/></>}></Route>
      <Route path="/Dashboard" element={<><Sidebar/><Dashboard/></>}></Route>
    

     
 </Routes>
 </BrowserRouter>
  )
}

export default App