import React from 'react'
import { NavLink} from 'react-router-dom'


function Sidebar() {
  return (
    <div className="main">
      <div className="navbar-side">
        <h6>
          <span className="icon"><i className="fas fa-code" /></span>
          <span className="link-text">Admin Panel</span>
        </h6>
        <ul>
          <li><NavLink to="/Dashboard" className="link-active" title="Dashboard">
            <span className="icon"><i className="fas fa-chart-bar" /></span>
            <span className="link-text">Dashboard</span>
          </NavLink></li>

          <li>
            <NavLink to="#" className="myBtn" data-toggle="collapse" data-target="#my-sub" title="User" aria-expanded="false" aria-controls="#my-sub">
              <span className="icon"><i className="fa fa-users" /></span>
              User
            </NavLink>
            <div id="my-sub" className=" bg-secondary">
            <li className="nav-item ">
                    <NavLink className="nav-link" to="/Add_User">
                    <span className="icon"><i className="fa fa-user-plus" /></span>
                    Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_User">
                    <span className="icon"><i className="fa fa-user-times" /></span>
                    Manage</NavLink>
                  </li>
            </div>
          </li>

          <li className="nav-item ms-7">
              <NavLink className="nav-link  " data-toggle="collapse" data-target="#dropdownExampleEmployee" aria-expanded="false" aria-controls="dropdownExampleEmployee">
              <span className="icon"><i className="fa fa-list-alt" /></span> Employe
              </NavLink>
              <div className="collapse" id="dropdownExampleEmployee">
                <ul className="nav flex-column bg-secondary">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_Employee">
                    <span className="icon"><i className="fa fa-user-plus" /></span>Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_employee">
                    <span className="icon"><i className="fa fa-user-times" /></span>Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>

            <li className="nav-item ms-7">
              <NavLink className="nav-link  " data-toggle="collapse" data-target="#dropdownExampleGuard" aria-expanded="false" aria-controls="dropdownExampleGuard">
              <span className="icon"><i className="fas fa-male" /></span>  Guard
              </NavLink>
              <div className="collapse" id="dropdownExampleGuard">
                <ul className="nav flex-column bg-secondary">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_Guard">
                    <span className="icon"><i className="fa fa-user-plus" /></span>Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_Guard">
                    <span className="icon"><i className="fa fa-user-times" /></span>Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
          
            <li className="nav-item ms-7">
              <NavLink className="nav-link  " data-toggle="collapse" data-target="#dropdownExampleProduct" aria-expanded="false" aria-controls="dropdownExampleProduct">
              <span className="icon"><i className="fas fa-database" /></span> Product
              </NavLink>
              <div className="collapse" id="dropdownExampleProduct">
                <ul className="nav flex-column bg-secondary">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_product">
                    <span className="icon"><i className="fa fa-user-plus" /></span>Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_product">
                    <span className="icon"><i className="fa fa-user-times" /></span>Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
         
            <li className="nav-item ms-7">
              <NavLink className="nav-link  " data-toggle="collapse" data-target="#dropdownExampleContect" aria-expanded="false" aria-controls="dropdownExampleContect">
              <span className="icon"><i className="fa fa-mobile" /></span> Contect
              </NavLink>
              <div className="collapse" id="dropdownExampleContect">
                <ul className="nav flex-column bg-secondary">
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Add_Contact">
                    <span className="icon"><i className="fa fa-user-plus" /></span>Add</NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink className="nav-link" to="/Manage_Contact">
                    <span className="icon"><i className="fa fa-user-times" /></span>Manage</NavLink>
                  </li>
                </ul>
              </div>
            </li>
          
        </ul>
      </div>
      <div className="content">
        <nav className="navbar navbar-dark bg-dark py-1">
          <a href="#" id="navBtn">
            <span id="changeIcon" className="fa fa-bars text-light" />
          </a>
          <div className="d-flex">
            <a className="nav-link text-light px-2" href="#"><i className="fas fa-search" /></a>
            <a className="nav-link text-light px-2" href="#"><i className="fas fa-bell" /></a>
            <a className="nav-link text-light px-2" href="#"><i className="fas fa-sign-out-alt" /></a>
          </div>
        </nav>
      </div>
    </div>



  )
}

export default Sidebar