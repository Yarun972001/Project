import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./Pages/Header";
import Home from "./Component/Home";
import About from "./Component/About";
import Service from "./Component/Service";
import Client from "./Component/Client";
import Contact from "./Component/Contact";
import Footer from "./Pages/Footer";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Login from './Component/Login';
import Signup from "./Component/Signup";
import Profile from "./Component/Profile";
import Gaurd from "./Component/Gaurd";

function App() {
  return (
  <BrowserRouter>
  <ToastContainer />
  <Routes>
    <Route path="/" element={<><Header/><Home/><About/><Service/><Client/><Contact/><Gaurd/><Footer/></>}></Route>
    <Route path="/About" element={<><Header/><About/><Footer/></>}></Route>
    <Route path="/Service" element={<><Header/><Service/><Footer/></>}></Route>
    <Route path="/Client" element={<><Header/><Client/><Footer/></>}></Route>
    <Route path="/Contact" element={<><Header/><Contact/><Footer/></>}></Route>
    <Route path="/Gaurd" element={<><Header/><Gaurd/><Footer/></>}></Route>
    <Route path="/Profile" element={<><Header/><Profile/><Footer/></>}></Route>

    <Route path="/login" element={<> <Header/><Login /><Footer /> </>}></Route>
    <Route path="/Signup" element={<> <Header/><Signup /><Footer /> </>}></Route>
  </Routes>
  </BrowserRouter>
  );
}

export default App;
