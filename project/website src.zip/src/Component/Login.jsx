import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Link,useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';


function Login() {

    const redirect=useNavigate();

    useEffect(()=>{
        if(localStorage.getItem('user_id'))
        {
            return redirect('/')
        }
    },[]);


    const [formvalue, setFormvalue] = useState({
        email: "",
        password: "",
    });

    const changeHandel = (e) => {  
        setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
        console.log(formvalue);
    }

    const vadidation = () => {
        var result = true;
        if (formvalue.email == "") {
            toast.error('email Field is required !')
            result = false;
        }
        if (formvalue.password == "") {
            toast.error('password Field is required !')
            result = false;
        }
        return result;
    }

    const submitHandel = async (e) =>  {
        e.preventDefault();
        if (vadidation()) {    
            const res = await axios.get(`http://localhost:3000/user?user_email=${formvalue.email}`);
            if(res.data.length>0)
            {
                if(res.data[0].user_password==formvalue.password)
                {
                    // create session
                    localStorage.setItem('user_name',res.data[0].name);
                    localStorage.setItem('user_id',res.data[0].id);
                    toast.success('Login Success');
                    setFormvalue({ ...formvalue,email: "", password: ""});
                    return redirect('/');
                }
                else
                {
                    toast.error('Invalid Password');
                    setFormvalue({ ...formvalue,email: "", password: ""});
                    return false;
                }
            }
            else
            {
                toast.error('Invalid Username');
                setFormvalue({ ...formvalue,email: "", password: ""});
                return false;
            }
        }
    }
                                

    return (
        <section className="contact_section layout_padding">
            <div className="container">
                <div className="heading_container">
                    <h2>
                        Login Us
                    </h2>
                </div>
                <div className="row">
                    <div className="col-md-12" >
                        <form action="" method="post" className="p-4 border">
                            <div className="mb-3">
                                <input type="email" className="form-control" style={{ color: "black" }} value={formvalue.email} onChange={changeHandel} name="email" placeholder="Email" />
                            </div>
                            <div className="mb-3"> 
                                <input type="password" className="form-control" style={{ color: "black" }} value={formvalue.password} onChange={changeHandel} name="password" placeholder="password" />
                            </div>

                            <div className="d-flex justify-content-between align-items-center">
                                <button onClick={submitHandel} className="btn btn-primary">
                                    Login
                                </button>
                            </div>
                            <Link to="/signup" className='float-right'>
                                If you Not regisered then Click here For Signup
                            </Link>
                        </form>
                    </div>
                    <div className="col-md-6">
                        <div className="map_container">
                            <div className="map">
                                <div id="googleMap" style={{ width: '100%', height: '100%' }} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Login