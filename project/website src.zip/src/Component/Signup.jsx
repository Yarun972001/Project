import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';


function Signup() {
    const redirect = useNavigate();

    useEffect(() => {
        if (localStorage.getItem('user_id')) {
            return redirect('/')
        }
    }, []);

    const [formvalue, setFormvalue] = useState({
        id: "",
        user_name: "",
        user_email: "",
        user_password: "",
        user_number: "",
        user_img: ""
    });

    const changeHandel = (e) => {
        setFormvalue({ ...formvalue, id: new Date().getTime().toString(), [e.target.name]: e.target.value });
        console.log(formvalue);
    }

    const vadidation = () => {
        var result = true;
        if (formvalue.user_name == "") {
            toast.error('Name Field is required !')
            result = false;
        }
        if (formvalue.user_email == "") {
            toast.error('email Field is required !')
            result = false;
        }
        if (formvalue.user_password == "") {
            toast.error('password Field is required !')
            result = false;
        }
        if (formvalue.user_number == "") {
            toast.error('mobile Field is required !')
            result = false;
        }
        if (formvalue.user_img == "") {
            toast.error('Image Field is required !')
            result = false;
        }
        return result;
    }

    const submitHandel = async (e) => {
        e.preventDefault();
        if (vadidation()) {
            const res = await axios.post(`http://localhost:3000/user`, formvalue);
            if (res.status == 201) {
                toast.success('Signup Success');
                setFormvalue({ ...formvalue, user_name: "", user_email: "", user_password: "", user_img: "", user_number: "" });
                return false;
            }
        }

    }

    return (
        <section className="contact_section layout_padding">
            <div className="container">
                <div className="heading_container">
                    <h2>
                        Signup Us
                    </h2>
                </div>
                <div className="row">
                    <div className="col-md-12" >
                        <form action="" method="post" className="p-4 border">
                            <div className="mb-3">
                                <input type="text" className="form-control" value={formvalue.user_name} onChange={changeHandel} name="user_name" placeholder="Name" />
                            </div>
                            <div className="mb-3">
                                <input type="email" className="form-control" value={formvalue.user_email} onChange={changeHandel} name="user_email" placeholder="Email" />
                            </div>
                            <div className="mb-3">
                                <input type="password" className="form-control" value={formvalue.user_password} onChange={changeHandel} name="user_password" placeholder="Password" />
                            </div>
                            <div className="mb-3">
                                <input type="number" className="form-control" value={formvalue.user_number} onChange={changeHandel} name="user_number" placeholder="Mobile" />
                            </div>
                            <div className="mb-3">
                                <input type="url" className="form-control" value={formvalue.user_img} onChange={changeHandel} name="user_img" placeholder="URL" />
                            </div>
                            <div className="d-flex justify-content-between align-items-center">
                                <button onClick={submitHandel} className="btn btn-primary">
                                    Signup
                                </button>
                                <Link to="/login" className='float-end'>
                                    If you already registered, Click here to Login
                                </Link>
                            </div>
                        </form>

                    </div>
                    <div className="col-md-6">
                        <div className="map_container">
                            <div className="map">
                                <div id="googleMap" style={{ width: '100%', height: '100%' }} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Signup