import axios from 'axios';
import React from 'react'
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react'

function Profile() {

    const [singledata, setsingleData] = useState("");
    const redirect = useNavigate();
    useEffect(() => {
        if (localStorage.getItem('user_id')) {

        }
        else {
            return redirect('/')
        }
    }, []);

    useEffect(() => {
        fetch();
    }, []);

    const fetch = async () => {
        const res = await axios.get(`http://localhost:3000/user/${localStorage.getItem('user_id')}`);
        //console.log(res.data);
        setsingleData(res.data)
    }

    return (
        <section className="about_section layout_padding">
            <div className="container">
                <div className="heading_container heading_center">
                    <h2>
                        My Profile
                    </h2>
                </div>
                <div className="row">
                    <div className="col-lg-8 col-md-8">
                        <div className="detail-box">
                            <h2>Name: {singledata.user_name}</h2>
                            <p>Email: {singledata.user_email}</p>
                            <p>Mobile: {singledata.user_number}</p>
                            <a href="#" className="btn btn-primary">Edit Profile</a>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4">
                        <div>
                            <img src={singledata.user_img} alt="User Image" className='img-thumbnail border border-info border border-4' />
                        </div>
                    </div>
                </div>
            </div>
        </section>


    )
}

export default Profile