import React,{useState} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';

function Contact() {
    const [formvalue,setFormvalue]=useState({
        id:"",
        contact_name:"",
        contact_email:"",
        contact_msg:"",
        contact_number:""
    });
    const changeHandel=(e)=>{
        setFormvalue({...formvalue,id: new Date().getTime().toString(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }
    
    const vadidation = () => {
      var result = true;
      if (formvalue.name == "") {
          toast.error('Name Field is required !')
          result = false;
      }
      if (formvalue.email == "") {
          toast.error('email Field is required !')
          result = false;
      }

      if (formvalue.comment == "") {
          toast.error('comment Field is required !')
          result = false;
      }
      return result;
  }
    const submitHandel = async (e) => {
      e.preventDefault();
      if (vadidation()) {
          const res = await axios.post(`http://localhost:3000/contact`, formvalue);
          if (res.status == 201) {
              toast.success('contact Add Success');
              setFormvalue({ ...formvalue, contact_name:"", contact_email:"", contact_msg:"",contact_number:""});
              return false;
          }
      }

  }
  return (
 <section className="contact_section layout_padding">
  <div className="contact_bg_box">
    <div className="img-box">
      <img src="images/contact-bg.jpg" alt />
    </div>
  </div>
  <div className="container">
    <div className="heading_container heading_center">
      <h2>
        Get In touch
      </h2>
    </div>
    <div className>
      <div className="row">
        <div className="col-md-7 mx-auto">
          <form action="#">
            <div className="contact_form-container">
              <div>
                <div>
                <input name="contact_name" type='text' className="form-control" onChange={changeHandel} value={formvalue.contact_name} id="name" placeholder="Enter your name" required />
                </div>
                <div>
                <input name="contact_email" type='email' className="form-control" onChange={changeHandel} value={formvalue.contact_email} id="email" placeholder="Enter your email" required />
                </div>
                <div>
                <input name="contact_number" type='number' className="form-control" onChange={changeHandel} value={formvalue.contact_number} id="number" placeholder="Enter your number" required />
                </div>
                <div className>
                <textarea name="contact_msg" className="form-control" id="message" onChange={changeHandel} value={formvalue.contact_msg} rows={4} placeholder="Enter your message" required defaultValue={""} />
                </div>
                <div className="btn-box ">
                <button type="submit" className="btn btn-primary"  onClick={submitHandel}>Submit</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>


  )
}

export default Contact