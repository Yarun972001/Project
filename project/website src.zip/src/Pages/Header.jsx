import React from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';

function Header() {
  const redirect = useNavigate();
  const logout = () => {
      localStorage.removeItem('user_id');
      localStorage.removeItem('user_name');
      toast.success('Logout Success');
      return redirect('/');
  }
  return (
    <>
  <div className="hero_bg_box">
    <div className="img-box">
      <img src="images/hero-bg.jpg" alt />
    </div>
  </div>
  <header className="header_section">
    <div className="header_top">
      <div className="container-fluid">
        <div className="contact_link-container">
          <NavLink to="" className="contact_link1">
            <i className="fa fa-map-marker" aria-hidden="true" />
            <span>
              Lorem ipsum dolor sit amet,
            </span>
          </NavLink>
          <NavLink to='' className="contact_link2">
            <i className="fa fa-phone" aria-hidden="true" />
            <span>
              Call : +01 1234567890
            </span>
          </NavLink>
          <NavLink href className="contact_link3">
            <i className="fa fa-envelope" aria-hidden="true" />
            <span>
              demo@gmail.com
            </span>
          </NavLink>
        </div>
      </div>
    </div>
    <div className="header_bottom">
      <div className="container-fluid">
        <nav className="navbar navbar-expand-lg custom_nav-container">
          <NavLink className="navbar-brand" href="index.html">
            <span>
              Guarder
            </span>
          </NavLink>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className />
          </button>
          <div className="collapse navbar-collapse ml-auto" id="navbarSupportedContent">
            <ul className="navbar-nav  ">
              <li className="nav-item active">
                <NavLink className="nav-link" to="/">Home <span className="sr-only">(current)</span></NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link" to="/About"> About</NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link" to="/Service"> Services </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link" to="/Gaurd"> Guards </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link" to="/Contact">Contact us</NavLink>
              </li>
              {/* <li className="nav-item">
                <NavLink className="nav-link" to="/Login">Login</NavLink>
              </li> */}
              {(() => {
                  if (localStorage.getItem('user_id')) {
                    return (
                      <>
                        <li className="nav-item">
                          <NavLink className="nav-link" to="/Profile">MyAccount</NavLink>
                        </li>

                        <li className="nav-item">
                          <a className="nav-link" onClick={logout} href="javascript:void(0)">Logout</a>
                        </li>
                      </>
                    )
                  }
                  else {
                    return (
                      <li className="nav-item">
                        <NavLink className="nav-link" to="/signup">Signup</NavLink>
                      </li>
                    )
                  }
                })()}
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </header>

  </>

  )
}

export default Header