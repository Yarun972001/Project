import React from 'react'
import Navbar from '../Components/Navbar'
import Footer from '../Components/Footer'
import Heroimg2 from '../Components/Heroimg2'
import Pricingcard from '../Components/Pricingcard'
import Workcard from '../Components/Workcard'

function Service() {
  return (
    <div>
      <Navbar/>
      <Heroimg2 heading="Services" text="our Services"/>
      <Workcard/>
      <Pricingcard/>
      <Footer/>
    </div>
  )
}

export default Service