import React from 'react'
import Navbar from '../Components/Navbar'
import Footer from '../Components/Footer'
import Heroimg2 from '../Components/Heroimg2'
import Partnercontent from '../Components/Partnercontent'

function Partners() {
  return (
    <div>
      <Navbar/>
      <Heroimg2 heading="Partners" text="our partners"/>
      <Partnercontent/>
      <Footer/>
    </div>
  )
}

export default Partners