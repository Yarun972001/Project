import React from 'react'
import Navbar from '../Components/Navbar'
import Footer from '../Components/Footer'
import Heroimg2 from '../Components/Heroimg2'
import Teamcontent from '../Components/Teamcontent'

function Team() {
  return (
    <div>
      <Navbar/>
      <Heroimg2 heading="TEAM." text="our team" />
      <Teamcontent/>
      <Footer/>
    </div>
  )
}

export default Team