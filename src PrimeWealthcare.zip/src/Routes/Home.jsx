import React from 'react'
import Navbar from '../Components/Navbar'
import Heroimg from '../Components/Heroimg'
import Footer from '../Components/Footer'
import Workcard from '../Components/Workcard'
import Aboutcontent from '../Components/Aboutcontent'
import Partnercontent from '../Components/Partnercontent'
import Form from '../Components/Form'
import Teamcontent from '../Components/Teamcontent'

function Home() {
  return (
    <div>
    <Navbar/>
    <Heroimg/>
    <Aboutcontent/>
    <Workcard/>
    <Partnercontent/>
    <Teamcontent/>
    <Form/>
    <Footer/>
    </div>
  )
}

export default Home