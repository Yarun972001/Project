import React from 'react'
import "../style/Workcard.css"
import lifeinsurance from "../assets/lifeinsurance.png"
import accident_insurance from "../assets/accident_insurance.png"
import fire_insurance from "../assets/fire_insurance.png"
import health_insurance from "../assets/health_insurance.png"
import money_insurance from "../assets/money_insurance.png"
import travel_insurance from "../assets/travel_insurance.png"
import vehicle_insurance from "../assets/vehicle_insurance.png"
import workmen_insurance from "../assets/workmen_insurance.png"
import house_insurance from "../assets/house_insurance.png"
import { NavLink } from 'react-router-dom'

function Workcard() {
  return (
    <div className='work-container'>
        <h1 className='project-heading'>Services</h1>
        <hr />
        <div className="left">
          <div className="amazing">
            <h4>
              <h1>Feel Amazing About
              Your Insurance</h1>
              <hr />
            </h4>
          </div>

        </div>
        <div className="project-container">
            <div className="project-card">
                <img src={lifeinsurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Life Insurance </h2>
                <div className="pro-details">
                    <p>We Offer A Plethora Of Life Insurance Policies Through The Channel Of LIFE CORPORATION OF INDIA (L.I.C).</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={accident_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Personal Accident Insurance </h2>
                <div className="pro-details">
                    <p>Medical Coverage Is Provided To The Insured On Accidental Emergencies.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={fire_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Fire Insurance </h2>
                <div className="pro-details">
                    <p>Provides Additional Coverage For Loss Or Damage To A Structure Damaged Or Destroyed In A Fire</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={health_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Health Insurance </h2>
                <div className="pro-details">
                    <p>Medical Coverage Is Provided To The Insured During Healthcare Emergencies.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={money_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Money In Transit Insurance </h2>
                <div className="pro-details">
                    <p>Provides Coverage Against Loss Of Cash Or Currency Whilst In Transit As Well As In Your Premises Due To Accident Or Misfortune.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={travel_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Travel Insurance </h2>
                <div className="pro-details">
                    <p>Covers Unexpected Medical Losses Incurred While Travelling Internationally Or Domestically.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={vehicle_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Vehicle Insurance </h2>
                <div className="pro-details">
                    <p>Financial Coverage Against Unforseen Events Suggest Accident Causing Vehicles Damages.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={workmen_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>Workmen Compensation Insurance </h2>
                <div className="pro-details">
                    <p>Providing For The Payment Of Compensation To Employer On Behalf Of It's Employees In Case Of Accidental Injury At Work Place.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
            <div className="project-card">
                <img src={house_insurance} alt="lifeinsurance"  />
                <h2 className='project-title'>House / Office Insurance </h2>
                <div className="pro-details">
                    <p>1.House Insurance Policy Provides Coverage For Your Own House , Ranted House , Apartment Or Luxury Mension As Well.
                    2. Office Insurance Offers Comprehensive Coverage For The Risk Associated With Threates Which Can Impact Office Operations. It Covers Not Only The Office Property But Also The Loss Of Money Or Any Cheating Done By Employees.</p>
                    <div className="pro-btns">
                        <NavLink to="url.com" className="btn">View</NavLink>
                        <NavLink to="url.com" className="btn">Source</NavLink>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Workcard