import React from "react";
import "../style/Form.css";
import {
  FaFacebook,
  FaHome,
  FaInstagram,
  FaLinkedin,
  FaMailBulk,
  FaPhone,
  FaTwitter,
} from "react-icons/fa";
import location_icon from "../assets/location_icon.png";
import mobile_icon from "../assets/mobile_icon.png";

function Form() {
  return (
    <div className="form">
      <h1 className="project-heading">
        {" "}
        C <span className="Arunn"> O </span> N<span className="Arunn"> T </span>{" "}
        A <span className="Arunn"> C </span> T{" "}
      </h1>
      <hr />
      <div className="footer-container">
        <div className="left">
          <div className="location">
            <h4>
              <h1>OFFICE ADDRESS</h1>
              <hr />
              <div className="phone">
                <h4 style={{ color: "#2c9486" }}>
                  <img src={mobile_icon} alt="" />
                  +91 9 104 105 104
                </h4>
              </div>
              <div>
                <h3>Ahmedabad</h3>
                <p>
                  <img src={location_icon} alt="" /> 510, Shivalik Satyamev, Nr.
                  Vakil Saheb Bridge,
                </p>
                <p>Ambali-Bopal Junction Ahmedabad</p>
              </div>
              <div>
                <h3>Bhavnagar</h3>
                <p>
                  <img src={location_icon} alt="" />
                  403/404, Bhayani Skyline, Atabhai Road, Nr. Prayosha Fast
                  Food, Opp. Jogger's Park, Bhavnagar- 364002
                </p>
              </div>
              <div>
                <h3>Surat</h3>
                <p>
                  <img src={location_icon} alt="" />
                  262, Silverstone Arcade, Causeway Rd, near D-Mart, Katargam, Surat, Gujarat 395004
                </p>
              </div>

            </h4>
          </div>
          {/* <div className="email">
            <h4 style={{color:"#2c9486" }}>
              
              primewealthcaresolution@gmail.com
            </h4>
          </div> */}
          {/* <br /> */}
          {/* <div className="phone">
            <h4 style={{color:"#2c9486" }}>
              <img src={mobile_icon} alt="" />

              +91  9 104 105 104
            </h4> 
          </div>   */}
        </div>

        <div className="right">
          <h4 style={{ color: "#2c9486" }}>
            <h1>INQUIRY OF INSURANCE</h1>
            <hr />
          </h4>
          <p style={{ color: "#2c9486" }}>
            <h2>Insurance at Prime wealthcare PVT. LTD. is Pleasure</h2>
          </p>
         <div className="map">
          <div className="map1">
                  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14687.73212333977!2d72.476049!3d23.026231!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e9dc1c8c3827d%3A0x81100dd58db9dd9f!2sPRIME%20WEALTHCARE%20SOLUTION%20IMF%20PVT.%20LTD!5e0!3m2!1sen!2sin!4v1718702586520!5m2!1sen!2sin" width="600" height="450" allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"/>  
          </div>  
          </div>
        </div>
      </div>
      <hr />
      <form>
        <label>Your Name</label>
        <input type="text"></input>
        <label>Email</label>
        <input type="email"></input>
        <label>Phone</label>
        <input type="number"></input>
        <label>Message</label>
        <textarea rows="6" placeholder="Type your msg here" />
        <button className="btn">Submit</button>
      </form>
    </div>
  );
}

export default Form;
