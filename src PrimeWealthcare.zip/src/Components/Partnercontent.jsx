import React from "react";
import "../style/Partnercontent.css";
import future_img from "../assets/future_img.png";
import hdfc_img from "../assets/hdfc_img.png"
import care_img from "../assets/care_img.png"
import icici_img from "../assets/icici_img.png"
import niva_img from "../assets/niva_img.png"
import tata_img from "../assets/tata_img.png"
import iffco_img from "../assets/iffco_img.png"
import lic_img from "../assets/lic_img.png"


function Partnercontent() {
  return (
    <div className="work-container">
      <h1 className="project-heading">OUR INSURANCE PARTNERS</h1>
      <hr />
      <div className="container">
        <div className="left">
          <div className="partners">
            <h4>
              <h1>HEALTH INSURANCE</h1>
              <hr />
            </h4>
          </div>
        </div>
      </div>
      
      <section className="section section-default mt-none mb-none">
        <div className="container">
          {/* <h2 className="mb-sm">
            Our <strong>Partners</strong>
          </h2> */}
          <strong>
            <div className="row">
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={future_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={hdfc_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={care_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={icici_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={niva_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={tata_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={iffco_img}
                  />
                </div>
              </div>
              <div className="col-sm-6 col-md-4 col-lg-3">
                <div className="square-holder">
                  <img
                    alt
                    src={lic_img}
                  />
                </div>
              </div>
            </div>
          </strong>
        </div>
      </section>
    </div>
  );
}

export default Partnercontent;
