import React from 'react'
import "../style/Teamcontent.css"
import darshana_pandya from "../assets/darshana_pandya.png"
import piyush_pandya from "../assets/piyush_pandya.png"
// import mahul_pradhan from "../assets/mahul_pradhan.png"
import { FaFacebook, FaHome, FaInstagram, FaLinkedin, FaMailBulk, FaPhone, FaTwitter } from "react-icons/fa";

function Teamcontent() {
   
  return (
    <div className="work-container">
    <h1 className="project-heading">
    Pillars Of Prime Wealthcare PVT.</h1>
    <hr />
    {/* <div className="container">
      <div className="left">
        <div className="partners">
          <h4>
            <h1>HEALTH INSURANCE</h1>
            <hr />
          </h4>
        </div>
      </div>
    </div> */}

{/* Team Section Start */}
    <div className="container">
  <div className="row blog">
    <h1 className="center mx-auto text-center py-4">Our Team Members</h1>
    <div className="col-md-12">
      <div id="blogCarousel" className="carousel slide" data-ride="carousel">
        <ol className="invisible carousel-indicators">
          <li data-target="#blogCarousel" data-slide-to={0} className="active" />
          <li data-target="#blogCarousel" data-slide-to={1} />
        </ol>
        {/* Carousel items */}
        <div className="carousel-inner">
          <div className="carousel-item active">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src={piyush_pandya} />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Piyush Pandya</h3>
                    <span className="post">Founder President And MD</span>
                  </div>
                  <ul className="social">
                    <li>
                      <FaFacebook
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
               <FaInstagram
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src={darshana_pandya} />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Darshna Pandya</h3>
                    <span className="post">Director</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Markus Baas</h3>
                    <span className="post">Financial Expert</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Sophia Lee</h3>
                    <span className="post">Customer Support</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Sophia Lee</h3>
                    <span className="post">Customer Support</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            {/*.row*/}
          </div>
          {/*.item*/}
          <div className="carousel-item">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Ted Robbins</h3>
                    <span className="post">Law Expert</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Noel Flantier</h3>
                    <span className="post">Marketing Consultant</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-sm-6">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Ernesto Appia</h3>
                    <span className="post">Team Leader</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-lg-3 ">
                <div className="our-team">
                  <div className="pic">
                    <img src="https://i.ibb.co/L8Pj1mg/o6EuTCT6.jpg" />
                  </div>
                  <div className="team-content">
                    <h3 className="title">Rosita Jimenez</h3>
                    <span className="post">Marketing Consultant</span>
                  </div>
                  <ul className="social">
                    <li>
                      <a href="#" className="fa fa-envelope" />
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            {/*.row*/}
          </div>
          {/*.item*/}
        </div>
        {/*.carousel-inner*/}
      </div>
      {/*.Carousel*/}
    </div>
  </div>
</div>
{/* Team Section End */}
  </div>
  )
}

export default Teamcontent