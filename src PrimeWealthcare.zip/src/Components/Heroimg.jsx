import React from 'react'
import heroimg from "../assets/heroimg.jpg"
import { Link } from 'react-router-dom'
import "../style/Heroimg.css"

function Heroimg() {
  return (
    <div className="hero">
     <div className="mask">
        <img className='into-img' src={heroimg} alt="" />
     </div>
     <div className="content">
        <h2>With The Right Planning,You THRIVE!</h2>
        <h1>Planning Se, Sab </h1>
          <h1> Mumkin Hai!</h1>
        <div>
            <Link to='/Contact' className='btn' >
            Contact Us
            </Link>
        </div>
     </div>
    </div>
  )
}

export default Heroimg