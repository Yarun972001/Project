import React from "react";
import "../style/Footer.css";
import { FaFacebook, FaHome, FaInstagram, FaLinkedin, FaMailBulk, FaPhone, FaTwitter } from "react-icons/fa";

function Footer() {
  return (
    <div className="footer">
      <div className="footer-container">
        <div className="left">
          <div className="location">
            <h4>
            <FaHome size={20} style={{ color: "white", marginRight: "2rem" }} />
            <div>
              <p style={{color:"white"}}> 510, Shivalik Satyamev, Nr. Vakil Saheb Bridge, </p>
              <p style={{color:"white"}}>Ambali-Bopal Junction Ahmedabad</p>
            </div>
            </h4>
          </div>
          <div className="email">
            <h4 style={{color:"white" }}>
              <FaMailBulk
                size={20}
                style={{ color: "white", marginRight: "2rem" }}
              />
              primewealthcaresolution@gmail.com
            </h4>
          </div>
          <br />
          <div className="phone">
            <h4 style={{color:"white" }}>
              <FaPhone
                size={20}
                style={{ color: "white", marginRight: "2rem" }}
              />
              +91  9 104 105 104
            </h4>
            
          </div>
          
        </div>

        <div className="right">
          <h4 style={{color:"white" }} > <b> About the Company </b></h4>
          <p style={{color:"white"}} >
            Prime Wealthcare Pvt. is the outcome of years of cumulative
            expertise of the founders in the insurance industry. It is the brain
            child of a team of seasoned financial advisors and planners.
          </p>
          <div className="social">
          <FaFacebook
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
              <FaTwitter
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
              <FaLinkedin
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
              <FaInstagram
                size={30}
                style={{ color: "white", marginRight: "1rem" }}
              />
              
          </div>
          
        </div>
      </div>
      <div className="last">
        <span>  Design & Develop </span>  <span className="text-danger"> ♥ </span> <span style={{color:"white"}}>  by Arun Yadav </span>
      </div>
      <div className="copyrights">
        <h4 style={{color:"white"}}>
©Prime Wealthcare Solution. All Right Reserved</h4>
      </div>
    </div>
  
  );
}

export default Footer;