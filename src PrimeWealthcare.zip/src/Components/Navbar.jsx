import React, { useState } from 'react'
import "../style/Navbar.css"
import { Link } from 'react-router-dom'
import {FaBars, FaTimes} from "react-icons/fa";
import logo2 from "../assets/logo2.png"

function Navbar() {

    const [click, setClick] = useState(false); 
const handleClick = () => setClick(!click)

const[color, setColor] = useState(false);
const changeColor = () =>{
    if (window.scrollY >= 1){
        setColor(true)
    } else {
        setColor(false)
    }
};

window.addEventListener("scroll", changeColor)




  return (
    <div className={color ? "header header-bg" : "header"}>
         <Link to="/">
            <img src={logo2} alt="Prime Wealthcare" height={90} />
            {/* <h1>P<span className="Arunn"> W </span> S </h1> */}
        </Link>
        <ul className={click ? "nav-menu active" : "nav-menu"}>
            <li>
                <Link to="/About">About Us</Link>
            </li>
            <li>
                <Link to="/Service">Service</Link>
            </li>
            <li>
                <Link to="/Partners">Partners</Link>
            </li>
            <li>
                <Link to="/Team">Team</Link>
            </li>
            <li>
            <Link to="/Contact">Contact Us</Link>
            </li>
        </ul>
        <div className='hamburger' onClick={handleClick}>
            {click ? (<FaTimes size={20} style={{ color: "rgba(2, 2, 32, 0.983)" }} />
            ) : ( <FaBars size={20} style={{ color: "#DBFAF1" }}/> ) }     
        </div>
    </div>
  )
}

export default Navbar