import React from 'react'
import "../style/Aboutcontent.css"
import { Link } from 'react-router-dom'
import team from "../assets/team.png"
import logo from "../assets/logo.jpg"

function Aboutcontent() {
  return (
    <div className='work-container'>
<h1 className='project-heading'>About Us</h1>
<hr />
    <div className='about'> 
        <div className="left">
        <h1>EXPLORE OUR JOURNEY</h1>
        <p>Prime wealthcare is the outcome of years of cumulative expertise of the founders in the insurance industry. It is the brain child of a team of seasoned financial advisors and planners. We understand how overwhelming and confusing money matters can get. Most people fail because they fail to plan ahead in time. Prime Wealthcare is conceptualized out of this need to bring about a financial liberation and facilitate a more positive relationship with money.</p>
        <p>At the heart of the organisation, lies a simple philosophy- “to assist individuals life financially planned so that they not only survive but thrive”. And with this goal in mind, Prime Wealthcare offers a bouquet of customized services for life insurance, health insurance, Travel insurance and others. We operate out of fully established offices in prime locations across major cities of Gujarat. We are equipped and committed to bringing financial joy and freedom in the lives of our clients through appropriate and timely solution.</p>
        <p>Why worry about finances, when you can work them out? Let's show you how!</p>
        <Link to="/Contact">
        <button className='btn'>Contact </button>
        </Link>
        </div>
        <div className="right">
        <div className="img-container">
            <div className="img-stack top">
                <img src={logo} alt="" className='img' />
            </div>
            <div className="img-stack bottom">
                <img src={team} alt="" className='img' />
            </div>
        </div>
        </div>
    </div>

 <section className="features">
  <div className="features_section">
    <div className="container pb-5">
      <div className="row">
        <span className="features_title">STATISTICS OF PRIME WEALTHCARE SOLUTION</span>
        <p className="features_heading">Figures about our business and specialization</p>
      </div>
      <div className="row features_cat">
        <div className="col-xxl-6 col-lg-6 mt-5 ">
          <div className="row">
            <div className="col-xxl-2 col-4">
              <img src="https://primewealthcare.com/assets/images/landingpage/happy_client_icon.png" className="img-fluid animate__animated animate__rotateIn" alt />
            </div>
            <div className="col-xxl-10 col-8">
              <h2 className="features_mimi_title">Happy Client</h2>
              <p className="features_mimi_desc">8,000</p>
            </div>
          </div>
        </div>
        <div className="col-xxl-6 col-lg-6  mt-5  ">
          <div className="row">
            <div className="col-xxl-2 col-4">
              <img src="https://primewealthcare.com/assets/images/landingpage/insurance_project_icon.png" className="img-fluid animate__animated animate__rotateIn" alt />
            </div>
            <div className="col-xxl-10 col-8">
              <h2 className="features_mimi_title">Insurance Project</h2>
              <p className="features_mimi_desc">300</p>
            </div>
          </div>
        </div>
      </div>
      <div className="row pb-5">
        <div className="col-xxl-6 col-lg-6 mt-5  ">
          <div className="row">
            <div className="col-xxl-2 col-4 ">
              <img src="https://primewealthcare.com/assets/images/landingpage/professional_icon.png" className="img-fluid animate__animated animate__rotateIn" alt />
            </div>
            <div className="col-xxl-10 col-8">
              <h2 className="features_mimi_title">Professional Business Associates</h2>
              <p className="features_mimi_desc">73</p>
            </div>
          </div>
        </div>
        <div className="col-xxl-6 col-lg-6 mt-5 ">
          <div className="row">
            <div className="col-xxl-2 col-4">
              <img src="https://primewealthcare.com/assets/images/landingpage/years_of_exprience_icon.png" className="img-fluid animate__animated animate__rotateIn" alt />
            </div>
            <div className="col-xxl-10 col-8">
              <h2 className="features_mimi_title">Years Of Exprience</h2>
              <p className="features_mimi_desc">18</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

    </div>
  )
}

export default Aboutcontent