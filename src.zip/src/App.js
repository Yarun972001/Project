import React from 'react'
import Navbar from './Navbar'
import Navbar2 from './Navbar2'
import Main from './Main'


function App() {
  return (<>
    <Navbar/>
    <Navbar2/>
    <Main/>
    
    </>
  )
}

export default App