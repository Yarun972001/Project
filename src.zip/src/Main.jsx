import React from 'react'

function Main() {
    return (<>
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-12">
                    <img src="https://nest.whatsmenu.page/uploads/restorants/28172315-3e1a-40d4-aca5-6628f5573b2a_cover.jpg" width="100%" height="70%" alt />
                    <nav className="navbar navbar-expand-lg navbar-light bg-white ">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav color-dark-green b ">
                                <li className="nav-item active">
                                    <a className="nav-link" href="#"> <h3><b> Featured Categories </b></h3> </a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Coke & Milk</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Cofee & Tea</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Pet Foods</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#">Vegetables</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                    <div className="container">
                        <div className="row">
                            <div className="col-md-3 p-2">
                                <div className="card p-2">
                                    <div className="card-body">
                                        <img src="https://th.bing.com/th/id/OIP.XprgHSCfPgHBpfQBBfAWqwHaFb?w=269&h=196&c=7&r=0&o=5&dpr=1.3&pid=1.7" alt="" />
                                        <p className="card-text"><b>APPLE</b></p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 p-2">
                                <div className="card p-2">
                                    <div className="card-body">
                                        <img src="orange.png" ></img>
                                        <p className="card-text"><b>ORANGE</b></p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 p-2">
                                <div className="card p-2">
                                    <div className="card-body">
                                        <h5 className="card-title"><img src="OIP.png"></img></h5>
                                        <p className="card-text"><b>MANGO</b></p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 p-2">
                                <div className="card p-2">
                                    <div className="card-body">
                                        <h5 className="card-title"><img src='https://th.bing.com/th/id/OIP.BD3a3Gg4iRQK7_w4xLhbwgHaFY?w=254&h=185&c=7&r=0&o=5&dpr=1.3&pid=1.7'></img></h5>
                                        <p className="card-text"><b>KIWI</b></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>


    </>
    )
}

export default Main