import React from 'react'
import 'tachyons'

function Navbar2() {
    return (
        <>
            <nav className="navbar navbar-expand-lg navbar-light bg-light-green ">
                <div className="dropdown">
                    <button className="btn btn-success dropdown-toggle " type="button" data-toggle="dropdown">Dropdown
                        <span className="caret" /></button>
                    <ul className="dropdown-menu">
                        <li><a href="#">HTML</a></li>
                        <li><a href="#">CSS</a></li>
                        <li><a href="#">JavaScript</a></li>
                    </ul>
                </div>

                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon" />
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav color-dark-green b ">
                        <li className="nav-item active">
                            <a className="nav-link" href="#"> Home </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">About</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Shopes</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Vendors</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Blog</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Pages</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </>

    )
}

export default Navbar2